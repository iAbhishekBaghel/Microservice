package com.example.ebookstoreapp.services;

import com.example.ebookstoreapp.entities.Book;
import com.example.ebookstoreapp.repositories.BookStoreRepository;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookStoreService {

    @Autowired
    private BookStoreRepository bookStoreRepository;

    public List<Book> getAllBooks() {
        return bookStoreRepository.findAll();
    }

    public Book getBookById(int id) {
        return bookStoreRepository.findById(id).orElse(null);
    }

    @Transactional
    public void addBook(Book book) {
        bookStoreRepository.save(book);
    }

    public void updateBook(Book book) {
        bookStoreRepository.save(book);
    }

    public void deleteBookById(int id) {
        bookStoreRepository.deleteById(id);
    }

    public List<Book> findBooksByTitle(String title) {
        return bookStoreRepository.findByBookTitle(title);
    }

    public List<Book> findBooksByPublisherLike(String publisher) {
        return bookStoreRepository.findByBookPublisherLike(publisher);
    }

    public List<Book> findBooksByYear(int year) {
        return bookStoreRepository.findByBookYear(year);
    }
}
