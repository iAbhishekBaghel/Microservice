package com.example.ebookstoreapp.repositories;

import com.example.ebookstoreapp.entities.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookStoreRepository extends JpaRepository<Book, Integer> {
    List<Book> findByBookTitle(String title);
    List<Book> findByBookPublisherLike(String publisher);
    List<Book> findByBookYear(int year);
}
