package com.example.ebookstoreapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreappApplicationTests {

	@Test
	void contextLoads() {
	}

}
