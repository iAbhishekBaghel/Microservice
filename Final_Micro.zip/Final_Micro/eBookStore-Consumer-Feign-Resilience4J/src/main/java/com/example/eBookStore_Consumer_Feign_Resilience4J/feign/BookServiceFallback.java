package com.example.eBookStore_Consumer_Feign_Resilience4J.feign;

import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
public class BookServiceFallback implements BookServiceProxy {

    @Override
    public Object getBookById(Integer id) {
        return "Fallback response: Unable to retrieve book with ID " + id + " at the moment.";
    }

    @Override
    public List<Object> getAllBooks() {
        return Collections.singletonList("Fallback response: Unable to retrieve book list at the moment.");
    }
}
