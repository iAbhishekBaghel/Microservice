package com.example.eBookStore_Consumer_Feign_Resilience4J.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import java.util.Arrays;
import java.util.List;

@FeignClient(name = "book-service", fallback = BookServiceFallback.class)
public interface BookServiceProxy {

	@Retry(name = "book-service")
    @CircuitBreaker(name = "book-service", fallbackMethod = "fallbackMethodGetBookById")
    @GetMapping(value = "/books/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    Object getBookById(@PathVariable("id") Integer id);

	@Retry(name = "book-service")
    @CircuitBreaker(name = "book-service", fallbackMethod = "fallbackMethodGetAllBooks")
    @GetMapping(value = "/books", produces = MediaType.APPLICATION_JSON_VALUE)
    List<Object> getAllBooks();

    // Fallback methods
    default Object fallbackMethodGetBookById(Integer id, Throwable cause) {
        System.out.println("Exception raised with message: " + cause.getMessage());
        // Return a placeholder object or appropriate fallback response
        return new Object(); // Modify this as needed for your fallback logic
    }

    default List<Object> fallbackMethodGetAllBooks(Throwable cause) {
        System.out.println("Exception raised with message: " + cause.getMessage());
        return Arrays.asList(); // Return an empty list as a fallback
    }
}
