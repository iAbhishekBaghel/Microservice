package com.ebook.hystrix.service;
 
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
@Service
public class BookService {
 
    @Autowired
    private RestTemplate restTemplate;
 
    @HystrixCommand(fallbackMethod = "fallbackForGetBookById")
    public Object getBookById(Integer id) {
        String url = "http://book-service/books/" + id;
        return restTemplate.getForObject(url, Object.class);
    }
 
    // Fallback method if the book-service is down or unavailable
    public Object fallbackForGetBookById(Integer id) {
        // You can return a default response or an error message here
        return "Book information is currently unavailable. Please try again later.";
    }
}