package com.example.ebookstoreapp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.example.ebookstoreapp.entities.Book;
import com.example.ebookstoreapp.services.BookStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books") // Base URI for all endpoints
public class BookStoreController {

    @Autowired
    @Qualifier("bookStoreService")
    private BookStoreService bookStoreService;
    
    private static final Logger log = LoggerFactory.getLogger(BookStoreController.class);
    
    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Book> getBookById(@PathVariable int id) {
    	
    	log.debug("In getBookById with Id: " + id);
        Book book = bookStoreService.getBookById(id);
        log.debug("In getBookById with return value book: " + id);
        
        return book != null ? new ResponseEntity<>(book, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    

    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        bookStoreService.addBook(book);
        return new ResponseEntity<>(book, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable int id, @RequestBody Book bookDetails) {
        bookDetails.setId(id); // Set the ID for the book being updated
        bookStoreService.updateBook(bookDetails);
        return new ResponseEntity<>(bookDetails, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks(@RequestParam(required = false) Integer year) {
        if (year != null) {
            List<Book> books = bookStoreService.findBooksByYear(year);
            return new ResponseEntity<>(books, HttpStatus.OK);
        } else {
            List<Book> books = bookStoreService.getAllBooks();
            return new ResponseEntity<>(books, HttpStatus.OK);
        }
    }

   
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable int id) {
        bookStoreService.deleteBookById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/title/{title}")
    public ResponseEntity<List<Book>> findBooksByTitle(@PathVariable String title) {
        List<Book> books = bookStoreService.findBooksByTitle(title);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @GetMapping("/publisher/{publisher}")
    public ResponseEntity<List<Book>> findBooksByPublisher(@PathVariable String publisher) {
        List<Book> books = bookStoreService.findBooksByPublisherLike(publisher);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
}
