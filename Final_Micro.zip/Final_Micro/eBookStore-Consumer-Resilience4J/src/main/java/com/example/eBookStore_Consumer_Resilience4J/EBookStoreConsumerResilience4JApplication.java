package com.example.eBookStore_Consumer_Resilience4J;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBookStoreConsumerResilience4JApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerResilience4JApplication.class, args);
	}

}
