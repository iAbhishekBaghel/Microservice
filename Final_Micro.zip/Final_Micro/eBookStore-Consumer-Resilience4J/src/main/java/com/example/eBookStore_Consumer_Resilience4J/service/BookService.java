package com.example.eBookStore_Consumer_Resilience4J.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker; // Correct import
import io.github.resilience4j.retry.annotation.Retry;

@Service
public class BookService {

    @Autowired
    private RestTemplate restTemplate;

    @CircuitBreaker(name = "book-service", fallbackMethod = "fallbackForGetBookById")
    @Retry(name = "book-service")
    public Object getBookById(Integer id) {
        String url = "http://book-service/books/" + id;
        return restTemplate.getForObject(url, Object.class);
    }

    // Fallback method
    public Object fallbackForGetBookById(Integer id, Throwable throwable) {
        return "Fallback response: Unable to retrieve book with ID " + id + " at the moment.";
    }
}
