package com.example.eBookStore_Consumer_Resilience4J.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.eBookStore_Consumer_Resilience4J.service.BookService;

@RestController
public class BookConsumerRestController {

    @Autowired
    private BookService bookService;

    @GetMapping("/get-books/{id}")
    public ResponseEntity<Object> getBookById(@PathVariable("id") Integer id) {
        Object book = bookService.getBookById(id);
        return ResponseEntity.ok(book);
    }
}