package com.example.eBookStore_Consumer_Feign_Hystrix.feign.fallback;

import org.springframework.stereotype.Component;

import com.example.eBookStore_Consumer_Feign_Hystrix.feign.client.BookServiceProxy;

@Component
public class BookServiceFallback implements BookServiceProxy {

    @Override
    public Object getAllBooks() {
        return "Fallback response: Unable to retrieve all books at the moment.";
    }

    @Override
    public Object getBookById(Integer id) {
        return "Fallback response: Unable to retrieve book with ID " + id + " at the moment.";
    }
}