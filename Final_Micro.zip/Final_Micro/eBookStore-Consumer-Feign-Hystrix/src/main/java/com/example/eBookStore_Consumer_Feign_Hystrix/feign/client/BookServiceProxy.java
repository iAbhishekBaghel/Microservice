package com.example.eBookStore_Consumer_Feign_Hystrix.feign.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.eBookStore_Consumer_Feign_Hystrix.feign.fallback.BookServiceFallback;

@FeignClient(name = "book-service", fallback = BookServiceFallback.class)
public interface BookServiceProxy {

    @GetMapping("/books")
    Object getAllBooks();

    @GetMapping("/books/{id}")
    Object getBookById(@PathVariable("id") Integer id);
}