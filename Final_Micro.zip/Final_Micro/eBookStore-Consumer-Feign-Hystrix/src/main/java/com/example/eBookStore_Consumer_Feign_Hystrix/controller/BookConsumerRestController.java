package com.example.eBookStore_Consumer_Feign_Hystrix.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.eBookStore_Consumer_Feign_Hystrix.feign.client.BookServiceProxy;

@RestController
public class BookConsumerRestController {

    @Autowired
    private BookServiceProxy bookServiceProxy;

    @GetMapping("/get-books")
    public ResponseEntity<Object> getAllBooks() {
        Object books = bookServiceProxy.getAllBooks();
        return ResponseEntity.ok(books);
    }

    @GetMapping("/get-books/{id}")
    public ResponseEntity<Object> getBookById(@PathVariable("id") Integer id) {
        Object book = bookServiceProxy.getBookById(id);
        return ResponseEntity.ok(book);
    }
}