package com.example.eBookStore_Consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
