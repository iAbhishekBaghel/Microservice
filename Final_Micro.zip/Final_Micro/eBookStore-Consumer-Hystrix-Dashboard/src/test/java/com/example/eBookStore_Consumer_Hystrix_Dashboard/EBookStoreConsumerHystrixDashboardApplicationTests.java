package com.example.eBookStore_Consumer_Hystrix_Dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerHystrixDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
