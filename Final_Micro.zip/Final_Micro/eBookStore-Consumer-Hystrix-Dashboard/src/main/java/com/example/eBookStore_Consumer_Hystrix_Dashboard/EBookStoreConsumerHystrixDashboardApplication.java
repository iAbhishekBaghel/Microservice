package com.example.eBookStore_Consumer_Hystrix_Dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBookStoreConsumerHystrixDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerHystrixDashboardApplication.class, args);
	}

}
